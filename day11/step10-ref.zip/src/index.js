import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  state = {
    compvalue : ''
  }
  inputRef = React.createRef();
  outputRef = React.createRef();
  clickHandler = ()=>{
    this.outputRef.current.value = this.inputRef.current.value ;
    this.setState({
      compvalue : this.inputRef.current.value
    });
    setTimeout(()=>{
      this.outputRef.current.style = "border : 1px solid red";
    },2000)
  }
  render(){
    return <div>
            <h1>Using Element Ref</h1>
            <input ref={ this.inputRef } type="text"/>
            <button onClick={ this.clickHandler }>Click Me</button>
            <br/>
            <output ref={ this.outputRef }></output>
            <br />
            <p>{ this.state.compvalue }</p>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));