import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
import FunComp from './components/fun.component';
import FunMemoComp from './components/fun_memo.component';
import PureComp from './components/pure.component';

class MainApp extends Component{
  state = {
    power : 5
  }
  changePower = (evt)=>{
    this.setState({
      power : evt.target.value
    })
  }
  setPowerTo5 = ()=>{
    this.setState({
      power : 5
    })
  }
  render(){
    return <div>
            <h1>Main App</h1>
            <h2>Power in parent component : { this.state.power }</h2>
            <input onChange={ this.changePower } type="range" />
            <button onClick={ this.setPowerTo5 }>Set Power to 5</button>
            <hr />
            <ChildComp pow={ this.state.power }/>
            <PureComp pow={ this.state.power }/>
            <FunComp pow={ this.state.power }/>
            <FunMemoComp pow={ this.state.power }/>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));