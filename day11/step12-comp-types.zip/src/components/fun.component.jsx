function FunComp(props){
    console.log("Function Comp was rendered");
    return <div>
                <h1> Function Component </h1>
                <h2>Power is : { props.pow }</h2>
            </div>
}

export default FunComp;