import { Component } from "react";

class ChildComp extends Component{
    render(){
        console.log("Child Comp Render was called");
        return <div>
                    <h1> Child Component </h1>
                    <h2>Power is : { this.props.pow }</h2>
               </div>
    }
}

export default ChildComp