import { PureComponent } from "react";

class PureComp extends PureComponent{
    render(){
        console.log("Pure Comp Render was called");
        return <div>
                    <h1> Pure Component </h1>
                    <h2>Power is : { this.props.pow }</h2>
               </div>
    }
}

export default PureComp