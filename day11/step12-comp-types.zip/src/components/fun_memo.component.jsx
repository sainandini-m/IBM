import React from 'react';

function FunMemoComp(props){
    console.log("Function Memo Comp was rendered");
    return <div>
                <h1> Function Memo Component </h1>
                <h2>Power is : { props.pow }</h2>
            </div>
}

export default React.memo(FunMemoComp);