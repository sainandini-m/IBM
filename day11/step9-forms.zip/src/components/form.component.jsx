import { Component } from "react";
import './mystyle.css';

class FormComponent extends Component{
    state = {
        username : '',
        userage : 0
    }
    nameChangeHandler = (evt)=>{
        this.setState({
            username : evt.target.value
        })
    }
    ageChangeHandler = (evt)=>{
        this.setState({
            userage : evt.target.value
        })
    }
    submitHandler = (evt)=>{
       evt.preventDefault();
       if(this.state.username === '' && this.state.userage === 0){
           alert("Please fill the details required")
       }else{
           if(this.state.userage < 18){
               alert("you too young to join us")
           }else{
               evt.target.submit();
           }
       }
    }

    render(){
        return <div>
                    <div className="box">
                    <h1> Login Form </h1>
                    <form action="#" name="loginForm" onSubmit={ this.submitHandler }>
                        <label htmlFor="uname"> User Name : </label>
                        <input name="username" onChange={ this.nameChangeHandler } value={this.state.username} id="uname" type="text" />
                        <br/>
                        <label htmlFor="uage"> User Age : </label>
                        <input name="userage" onChange={ this.ageChangeHandler } value={this.state.userage} id="uage" type="number" />
                        <br/>
                        <button>Register</button>
                    </form>
                    </div>
                    <hr />
                    <p>User Name : <span>{ this.state.username }</span></p>
                    <p>User Age : <span>{ this.state.userage }</span></p>
                </div>
    }
}

export default FormComponent;