import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FormComponent from './components/form.component';

class MainApp extends Component{
  render(){
    return <div>
            <h1>IBM Application</h1>
            <hr/>
            <FormComponent/>
          </div>
  } 
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));