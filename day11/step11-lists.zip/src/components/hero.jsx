function HeroComp(props){

   let { name, url, power, 'full-name' : fname } = props.hdata;
   
   return <div> 
                <h1>{ name }</h1> 
                <h2>{ fname }</h2> 
                <img width="200" src={url} alt={name} />
                <h2>{ power }</h2>
         </div>
}

export default HeroComp;