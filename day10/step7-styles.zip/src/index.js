import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import clientStyle from './boxstyle.module.css';

import "./mystyle.css";

class MainApp extends Component{
  paraStyle = { 
    backgroundColor : 'darkslategray', 
    color : 'cornsilk',
    padding : '10px',
    fontFamily : 'Arial',
    textAlign : 'justify'
    }
  render(){
    return <div>
            <p style={ { 
              color: 'darkslategray', 
              backgroundColor : 'cornsilk',
              padding : '10px',
              fontFamily : 'Arial',
              textAlign : 'justify'
              } }>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas quis convallis sapien, in euismod eros. Ut a purus eget lacus hendrerit tempus. Ut orci tortor, finibus ornare urna nec, tincidunt lobortis velit. Aliquam at lobortis risus. Donec maximus augue in pharetra fringilla. Nullam magna ipsum, egestas sit amet libero ac, auctor dignissim tortor. Mauris vehicula fermentum ligula quis rhoncus. Nam at libero in lectus fringilla ornare.
            </p>

            <p  style={ this.paraStyle }>
              Ut a velit ac sapien bibendum iaculis quis semper odio. Duis rhoncus metus velit, quis facilisis augue dignissim in. Nam vitae ligula est. Suspendisse venenatis nibh ut magna facilisis tincidunt. Nulla ligula ex, rutrum ac commodo non, fringilla nec tellus. Etiam auctor lectus ut malesuada vehicula. Aliquam eu mauris nibh. Integer sollicitudin porttitor ligula, ut volutpat purus volutpat eget. Fusce euismod porttitor sem. Donec elementum eu ipsum id commodo. Mauris eu ipsum fringilla, egestas ex id, rutrum quam. Nulla at blandit ex. Aenean et ante sit amet purus rhoncus interdum. Sed sed justo auctor, cursus leo non, laoreet metus. Vestibulum feugiat consequat scelerisque. Donec eget libero varius, hendrerit justo congue, faucibus lectus.
            </p>

            <p style={ this.paraStyle }>
              Sed dictum quis elit a vestibulum. Curabitur eu arcu nisi. Nam aliquet ornare dolor, at ullamcorper sapien auctor non. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Maecenas id consequat est, sed sodales nulla. Duis at velit maximus, dictum purus a, semper urna. Aliquam mattis libero sit amet ante fringilla interdum. Integer sit amet odio a turpis pulvinar imperdiet sed non enim. In non sagittis lacus. Sed fermentum euismod leo, a condimentum est. Fusce pellentesque sem sem, a fermentum turpis commodo sed. Nullam vel enim venenatis, tempor massa ac, fringilla massa. Nunc sit amet nulla pharetra, elementum sem quis, malesuada lectus. Etiam posuere consequat commodo. Suspendisse ut interdum mauris. Integer non turpis dolor.
            </p>

            <p className="player">
              Ut euismod volutpat tincidunt. Nullam risus sapien, tincidunt vel bibendum sed, ornare vel magna. Nulla dignissim fringilla elit ac ultrices. Phasellus maximus, tortor nec congue volutpat, orci sem hendrerit magna, vitae commodo diam nisl sit amet elit. Nulla magna magna, scelerisque rutrum hendrerit id, venenatis eget sapien. Fusce vulputate auctor leo, sit amet faucibus arcu pulvinar ut. Vestibulum erat diam, maximus in lectus a, tempor finibus erat. Aliquam nec tincidunt mauris. Integer feugiat metus in purus ullamcorper auctor. Proin mattis eu turpis a porttitor. Donec vestibulum felis lacinia laoreet scelerisque. Donec leo nunc, finibus a lacinia sit amet, rhoncus nec mauris. Morbi quis finibus nibh, a porttitor dolor. Cras et eros ac nunc hendrerit convallis. Nam lacinia neque non diam auctor, eu consectetur erat iaculis.
            </p>

            <p className="box">
              Morbi convallis nisi at quam vulputate, at tempus sapien auctor. Fusce condimentum lacus eget porta dictum. Curabitur ultrices nulla arcu, eget hendrerit arcu consectetur at. Suspendisse euismod nisl quis vulputate vestibulum. Mauris vehicula dui non iaculis dapibus. Nunc pretium ligula id justo rutrum, euismod pellentesque metus ultricies. Maecenas a sem neque. Sed eu vestibulum mi. Sed magna turpis, iaculis vel nunc sed, commodo semper augue. Integer euismod, turpis ultricies fringilla aliquet, sapien nisl hendrerit leo, varius commodo odio dolor eget augue. Morbi placerat ante accumsan, faucibus est quis, varius eros. 
            </p>
            
            <p className={ clientStyle.box }>
              Morbi convallis nisi at quam vulputate, at tempus sapien auctor. Fusce condimentum lacus eget porta dictum. Curabitur ultrices nulla arcu, eget hendrerit arcu consectetur at. Suspendisse euismod nisl quis vulputate vestibulum. Mauris vehicula dui non iaculis dapibus. Nunc pretium ligula id justo rutrum, euismod pellentesque metus ultricies. Maecenas a sem neque. Sed eu vestibulum mi. Sed magna turpis, iaculis vel nunc sed, commodo semper augue. Integer euismod, turpis ultricies fringilla aliquet, sapien nisl hendrerit leo, varius commodo odio dolor eget augue. Morbi placerat ante accumsan, faucibus est quis, varius eros. 
            </p>
            
          </div>
  }
}


ReactDOM.render(<MainApp/>,document.getElementById('root'));