import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <h1> Hello from Child Component </h1>
    }
}

export default ChildComp;