import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/*
Mounting
  constructor
  getDerivedStateFromProps (static)
  render
  componentDidMount

Update
  getDerivedStateFromProps (static)
  shouldComponentUpdate
  render
  getSnapshotBeforeUpdate
  componentDidUpdate

UnMount
  componentWillUnmount

Error
  getDerivedStateFromError
  componentDidCatch
*/

class MainApp extends Component{
  state = {
    power : 0,
    title : "Batman"
  }
  constructor(){
    super();
    // this.state.power = 10;
    console.log("+++++++++++++++++++++++++++++++++++++");
    console.log("MainApp Constructor was called");
    this.increasePower = this.increasePower.bind(this);
  }
  increasePower(){
    this.setState({power : this.state.power + 1 })
  }
  static getDerivedStateFromProps(prop, state){
    console.log("MainApp getDerivedStateFromProps was called");
    return {
      power : prop.npower
    };
  }
  shouldComponentUpdate(){
    console.log("MainApp shouldComponentUpdate was called");
    return true
  }
  componentDidMount(){
    console.log("MainApp componentDidMount was called");
    console.log("+++++++++++++++++++++++++++++++++++++");
  }
  getSnapshotBeforeUpdate(){
    console.log("MainApp getSnapshotBeforeUpdate was called");
    return true;
  }
  componentDidUpdate(){
    console.log("MainApp componentDidUpdate was called");
  }
  render(){
    console.log("MainApp Render was called");
    return <div>
            <h1>Welcome to your life </h1>
            <h2>Power is : { this.state.power }</h2>
            <button onClick={ this.increasePower }>Increase Power</button>
          </div>
  }
}
ReactDOM.render(<MainApp npower={6} version={101}/>,document.getElementById('root'));