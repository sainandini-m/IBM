import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  state = {
    power : 6
  }
  render(){
    /* if( this.state.power >= 5 ){
      return <h1> Hero is Strong </h1>
    }else{ 
      return <h1> Hero needs Rest </h1>
    } */
    // return this.state.power >= 5 ? <h1> Hero is Strong </h1> : <h1> Hero needs Rest </h1>
    return this.state.power >= 5 && <h1> Hero is Strong </h1>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));