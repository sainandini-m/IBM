import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <>
                <h1>Child Component</h1>
                <hr/>
                <ol>Version is { this.props.children }</ol>
                <h2>Displayed on Child Component : { this.props.msg }</h2>
                <button onClick={ ()=>{
                    this.props.handlerFun('child component says hi')
                }}>Click to change parent message</button>
               </>
    }
}

export default ChildComp;