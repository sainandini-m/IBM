import { Component } from "react";
import ChildComp from "./childcomp";

class ParentComp extends Component{
    state = {
        message : "Hello from Parent Component",
        version : 1001
    }
    changeMessage = (nmessage) => {
        this.setState({
            message : nmessage
        })
    }
    render(){
        return <>
                <h1>Parent Component</h1>
                <h2>Displayed on Parent : { this.state.message }</h2>
                <hr/>
                <ChildComp handlerFun={ this.changeMessage } msg={ this.state.message }>
                        <li>List Item</li>
                        <li>List Item</li>
                        <li>List Item</li>
                        <li>List Item</li>
                </ChildComp>
               </>
    }
}
export default ParentComp;