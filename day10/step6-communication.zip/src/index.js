import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ParentComp from './components/parentcomp';

class MainApp extends Component{
  render(){
    return <ParentComp/>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));