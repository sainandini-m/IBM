import { Component } from 'react';

class SecondComp extends Component{
    state = {
        power : 0
    }
    increasePower = () => {
        // this.setState({ 
        //     power : this.state.power + 1 
        // }, function(){
        //     console.log(this.state.power);
        // });

        this.setState((prevState, compProp) => {
            console.log("Previous State Value : ",prevState.power); 
            console.log("Component Property : ",compProp); 
            return { power : prevState.power+1 }
        }, function(){
            console.log("Current State Value : ",this.state.power )
        })
    }
    render(){
        return <div>
                    <h1>Second Component</h1>
                    <hr/>
                    <h2>Power is : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
               </div>
    }
}

export default SecondComp;