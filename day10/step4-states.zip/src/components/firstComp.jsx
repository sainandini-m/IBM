import { Component } from 'react';

class FirstComp extends Component{
    
    constructor(){
        super();
        this.state = {
            power : 0
        }
        // this.increasePower = this.increasePower.bind(this);
    }
    increasePower = () => {
        this.setState({ 
            power : this.state.power + 1 
        })
    }
    render(){
        return <div>
                    <h1>First Component</h1>
                    <hr/>
                    <h2>Power is : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
               </div>
    }
}

export default FirstComp;