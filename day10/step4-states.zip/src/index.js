import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FirstComp from './components/firstComp';
import SecondComp from './components/secondComp';

class MainComp extends Component{
  render(){
    return <React.Fragment>
            <FirstComp/>
            <SecondComp nPower={5}/>
          </React.Fragment>
  }
}

ReactDOM.render(<MainComp/>,document.getElementById('root'));