import React from 'react';
import ReactDOM from 'react-dom';
import MainAppComp from './MainApp';


ReactDOM.render(<MainAppComp />,document.getElementById('root')
);