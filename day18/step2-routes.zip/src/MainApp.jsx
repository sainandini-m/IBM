import { Component } from "react";
import HeroesHomeComp from './components/heroesHome';
import HulkComp from './components/hulk.component';
import IronmanComp from './components/ironman.component';
import NotFoundComp from './components/notfound.component';
import ScarletComp from './components/scarlet.component';
import { BrowserRouter, Route, Link, Switch, NavLink } from 'react-router-dom';
import "./mystyle.css";

class MainAppComp extends Component{
    state = {
        quantity : 0
    }
    changeHandler = (evt)=>{
        this.setState({
            quantity : evt.target.value
        })
    }
    render(){
        return <div>
                    <h1> Main App Component </h1>
                    <input type="range" value={ this.state.quantity } 
                    onChange={ this.changeHandler } />
                    Quantity : { this.state.quantity }
                    <hr />
                    <BrowserRouter>
                    {/* <ul>
                        <li> <a href="/"> Home </a></li>
                        <li> <a href="/hulk"> Hulk </a></li>
                        <li> <a href="/ironman"> Ironman </a></li>
                        <li> <a href="/scarlet"> Scarlet </a></li>
                    </ul> */}
                    <ul>
                        <li> <NavLink activeClassName="boxer" exact to="/"> Home </NavLink> </li>
                        <li> <NavLink activeClassName="boxer" to={ "/hulk/"+this.state.quantity  }> Hulk </NavLink></li>
                        <li> <NavLink activeClassName="boxer" to="/ironman"> Ironman </NavLink></li>
                        <li> <NavLink activeClassName="boxer" to="/scarlet"> Scarlet </NavLink></li>
                    </ul>
                    <Switch>
                        <Route path="/" exact component={ HeroesHomeComp }/>
                        <Route path="/hulk/:msg" component={ HulkComp }/>
                        <Route path="/hulk" component={ HulkComp }/>
                        <Route path="/ironman" component={ IronmanComp }/>
                        <Route path="/scarlet" component={ ScarletComp }/>
                        <Route component={ NotFoundComp }/>
                    </Switch>
                    </BrowserRouter>
               </div>
    }
}

export default MainAppComp;