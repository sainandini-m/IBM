import { Component } from "react";

class NotFoundComp extends Component{
    render(){
        return <div>
                    <h1> 404 : Component Not Found </h1>
                </div>
    }
}

export default NotFoundComp;