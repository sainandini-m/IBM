import { Component } from "react";

class HulkComp extends Component{
    render(){
        return <div>
                    <h1> Hulk Component </h1>
                    <h2>Quantity is : { this.props.match.params.msg || 'waiting'}</h2>
                </div>
    }
}

export default HulkComp;