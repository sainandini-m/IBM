import { Component } from "react";

class HeroesHomeComp extends Component{
    render(){
        return <div>
                    <h1> Heroes Home Component </h1>
                </div>
    }
}

export default HeroesHomeComp;