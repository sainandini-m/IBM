import { Component } from "react";

class ScarletWitchComp extends Component{
    render(){
        return <div>
                    <h1> Scarlet Witch Component </h1>
                </div>
    }
}

export default ScarletWitchComp;