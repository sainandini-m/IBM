const express = require("express");
const mongojs = require("mongojs");
//-----------------------------------
let app = express();
const port = process.env.PORT || 3030;
let db = mongojs("ibmdb", ["heros"]);
app.use(express.urlencoded({extended : true}));
//-----------------------------------
app.get("/", (req, res)=>{
    db.heros.find(function(error, documents){
        res.render("home.pug",{
            title : "IBM Heroes",
            heroes : documents
        })
    })
})
//-----------------------------------
app.post("/", (req, res)=>{
    db.heros.insert(req.body);
    res.redirect("/")
})
//-----------------------------------
app.listen(port);
console.log("server is now live on localhost : ", port);