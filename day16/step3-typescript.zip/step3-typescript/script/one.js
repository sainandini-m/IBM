"use strict";
var message = "Welcome to your life";
var count = 555;
var heroes = ['batman', 'Ionman'];
var Hero = /** @class */ (function () {
    function Hero(ntitle) {
        this.title = '';
        this.city = '';
        this.title = ntitle;
    }
    Hero.prototype.sayTitle = function () {
        return this.title;
    };
    return Hero;
}());
alert(message);
