let message:String = "Welcome to your life";
let count:Number = 555;
let heroes:Array<String> = ['batman','Ionman'];

interface IHero{
    title:string,
    city :string
}

class Hero implements IHero{
    title:string = '';
    city:string = '';
    constructor(ntitle:string){
        this.title = ntitle;
    }
    sayTitle():string{
        return this.title;
    }

}
alert(message); 