import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PowerClick from './components/PowerClick';
import PowerDrag from './components/PowerDrag';


class MainApp extends Component{
  render(){
    return <div>
            <h1>Welcome to your life </h1>
            <PowerClick version="101" team="Avengers"/>
            <hr />
            <PowerDrag version="201" team="Justice League"/>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));