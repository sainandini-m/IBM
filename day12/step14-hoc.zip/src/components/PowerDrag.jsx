import { Component } from "react"
import WithBooster from "./withBooster"

class PowerDrag extends Component{

    render(){
      return <div>
              <h1>Power is now : { this.props.pow }</h1>
              <h3>{ this.props.title }</h3>
              <h3>{ this.props.team }| Version is : { this.props.version }</h3>
              <div style={ { 
                width : '150px', 
                height : '50px', 
                backgroundColor : 'orange',
                border : '1px solid transparent',
                lineHeight : '50px',
                textAlign : 'center' } } onMouseMove={ this.props.boostPower }>Increase Power</div>
            </div>
    }
  }

  export default WithBooster(PowerDrag);