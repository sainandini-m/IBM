import { Component } from "react";
let WithBooster = ( OriginalComp ) => {
    class NewComp extends Component{
        state = {
            power : 0
          }
        increasePower = () => {
          this.setState({ power : this.state.power + 1 })
        }
        render(){
           // return <OriginalComp version={ this.props.version } appteam={ this.props.team } boostPower={ this.increasePower } pow={ this.state.power } title="Heroes Application"/>
            return <OriginalComp boostPower={ this.increasePower } pow={ this.state.power } title="Heroes Application" {...this.props} />
        }
    }
    return NewComp
}
export default WithBooster;