import { Component } from "react"
import WithBooster from "./withBooster"

class PowerClick extends Component{
  
    render(){
      return <div>
              <h1>Power is now : { this.props.pow }</h1>
              <h3>{ this.props.title }</h3>
              <h3>{ this.props.team }| Version is : { this.props.version }</h3>
              <button onClick={ this.props.boostPower }>Increase Power</button>
            </div>
    }
  }

  export default WithBooster(PowerClick);