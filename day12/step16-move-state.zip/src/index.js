import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import GrandComp from './components/grandComp';

class MainApp extends Component{
  render(){
    return <div style={ { margin : "auto", width : "1140px"}}>
            <h1> Main Application </h1>
            <GrandComp/>
          </div> 
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));