import { Component } from "react";
import Child1Comp from "./child1Comp";

class Parent1Comp extends Component{
    render(){
        return <div style={ { border : "2px solid red ", padding : "10px", margin : "10px", float : "left", width : "500px" } }>
                <h1>Hello from Parent1 Component</h1>
                <Child1Comp msg={ this.props.pmsg }/>
            </div>
    }
}

export default Parent1Comp;