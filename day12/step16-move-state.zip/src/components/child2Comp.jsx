import { Component } from "react";

class Child2Comp extends Component{
    render(){
        return <div style={ { border : "2px solid red ", padding : "10px", margin : "10px" } } >
                    <h1>Hello from Child2 Component</h1>
                    <h2>{ this.props.msg }</h2>
                </div>
    }
}

export default Child2Comp;