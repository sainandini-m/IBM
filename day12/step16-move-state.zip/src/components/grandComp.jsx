import { Component } from "react";
import Parent1Comp from "./parent1Comp";
import Parent2Comp from "./parent2Comp";

class GrandComp extends Component{
    state = {
        message : "** ~ Hi ~ **"
    }
    changeHandler = (evt)=>{
        this.setState({
            message : evt.target.value
        })
    }
    render(){
        return <div style={ { border : "2px solid red ", padding : "10px", margin : "10px", display : "table" } }>
                    <h1>Hello from Grand Component</h1>
                    <input onChange={ this.changeHandler } />
                    <hr />
                    <Parent1Comp pmsg={ this.state.message }/>
                    <Parent2Comp pmsg={ this.state.message }/>
                </div>
    }
}

export default GrandComp;