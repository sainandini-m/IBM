import { Component } from "react";
import Child2Comp from "./child2Comp";
import Child3Comp from "./child3Comp";

class Parent2Comp extends Component{
    render(){
        return <div  style={ { border : "2px solid red ", padding : "10px", margin : "10px", float : "left", width : "500px" } }>
                <h1>Hello from Parent2 Component</h1>
                <Child2Comp msg={ this.props.pmsg }/>
                <Child3Comp msg={ this.props.pmsg }/>
               </div> 
    }
}

export default Parent2Comp;