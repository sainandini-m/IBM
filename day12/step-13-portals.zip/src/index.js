import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class PortalApp extends Component{
    render(){
        return ReactDOM.createPortal(
            this.props.children,
            document.querySelector("#popup")
        )
    }
}
class MainApp extends Component{
    state = {
        showPopup : false
    }
    doShow = ()=>{
        this.setState({
            showPopup : true
        })
    }
    doHide = ()=>{
        this.setState({
            showPopup : false
        })
    }
    render(){
        if(this.state.showPopup){
            return <PortalApp>
                        <div>
                            <h2>Terms and Conditions</h2>
                            <p>
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Omnis, vero incidunt facere saepe atque consequuntur magnam maiores expedita, nam ab delectus magni beatae voluptatibus iusto debitis provident dolores id blanditiis.
                            </p>
                            <button onClick={this.doHide}>Close</button>
                        </div>
                  </PortalApp>
        }else{
            return <div>
                        <h1>Hello from Main App</h1>
                        <button onClick={this.doShow}>Show Terms and Conditions</button>
                        <h3>{ this.state.showPopup ? 'True' : 'False'}</h3>
                  </div>
        }


    }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));