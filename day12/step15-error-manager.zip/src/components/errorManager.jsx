import { Component } from "react";

class ErrorManager extends Component{
    state = {
        hasError : false,
        errorMessage : ''
    }
    // static getDerivedStateFromError(msg){
    //     return {
    //         hasError : true
    //     }
    // }
    componentDidCatch(error, errorComp){
        console.log(errorComp);
        this.setState({
            hasError : true,
            errorMessage : error+""
        })
    }
    render(){
        if(this.state.hasError){
            return <h3> { this.state.errorMessage } </h3>
        }else{
            return this.props.children;
        }
    }
}
export default ErrorManager;