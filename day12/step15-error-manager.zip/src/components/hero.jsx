import { Component } from "react";

class HeroComp extends Component{
    render() {
        if( this.props.power < 4 ){
            throw new Error('Hero cant participate');
        }else{
            return <h1>Hero's Power is : { this.props.power }</h1> ;
        }
    }
}

export default HeroComp;