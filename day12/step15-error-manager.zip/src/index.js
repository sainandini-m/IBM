import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ErrorManager from './components/errorManager';
import HeroComp from './components/hero';

class MainComp extends Component{
  render() {
    return (
      <div>
        <ErrorManager>
              <HeroComp power={ 5 }/>
        </ErrorManager>
        <ErrorManager>
              <HeroComp power={ 4 }/>
        </ErrorManager>
        <ErrorManager>
              <HeroComp power={ 3 }/>
        </ErrorManager>
      </div>
    );
  }
}

ReactDOM.render(<MainComp/>,document.getElementById('root'));