import {useState} from 'react';

function useToggle(initValue = false){
    const [state, setState] = useState(initValue);
    let toggle = ()=>{
        setState(!state)
    }
    return [state, toggle]
}

export default useToggle;