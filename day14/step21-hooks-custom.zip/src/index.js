import React from 'react';
import ReactDOM from 'react-dom';
import useToggle from './hooks/useToggle';

function MainApp(){
   // let [show, changeShow] = useState(false);
   let [show, changeShow] = useToggle(false);
  return <div>
          { show 
          ? <div> 
              <p>Terms & Conditions  : comes here </p> 
              <button onClick={()=> changeShow() }> Hide </button> 
            </div> 
          : <button onClick={()=> changeShow() }>show terms</button>}
        </div>
};

ReactDOM.render(<MainApp/>,document.getElementById('root'));