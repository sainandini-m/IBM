import React,{ useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import fetch from 'fetch';

function MainApp(){
  let [users, accessUsers] = useState([])
  useEffect(()=>{
    fetch.fetchUrl("https://jsonplaceholder.typicode.com/users", (err,meta, data)=>{
      if(err){
        console.log("Error : ", err);
      }else{
        accessUsers(JSON.parse(data));
      }
    })
  },[])
  return <div>
          <h1>Heroes List Application using Fetch</h1>
          {/* <button onClick={ clickHandler }>Get Data</button> */}
          <ul>
            { users.map(val => <li key={ val.id }>{val.name}</li>) }
          </ul>
        </div>
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));