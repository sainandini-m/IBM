import { useState } from "react";
import FamilyContext from "../context/family.context";
import GeneralContext from "../context/gen.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parentComp";

function GrandComp(){
    let [state, setState] = useState({message: 'grand parent message', version : 1001})

    let changeMessage = ()=>{
        setState({
            ...state,
            message : "Updated Message on "+new Date()
        })
    }
    let changeVersion = ()=>{
        setState({
            ...state,
            version : Math.round(Math.random() * 10000)
        })
    }
    return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                <h2>Grand Component</h2>
                <button onClick={ changeMessage }>Change Message</button>
                <button onClick={ changeVersion }>Change Version</button>
                <hr/>
                <FamilyContext.Provider value={ state.message }>
                    <GeneralContext.Provider value={ state.version }>
                        <ParentComp/>
                        <hr />
                        <CousinComp/>
                    </GeneralContext.Provider>
                </FamilyContext.Provider>
               </div>
}
export default GrandComp;