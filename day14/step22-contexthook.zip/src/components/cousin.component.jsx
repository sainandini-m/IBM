import { useContext } from "react";
import FamilyContext from "../context/family.context";
import GeneralContext from "../context/gen.context";

function CousinComp(){
    const msg = useContext( FamilyContext );
    const ver = useContext( GeneralContext );
    return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                    <h2>Cousin Component</h2>
                    <hr />
                    <FamilyContext.Consumer>{ (msg)=> {
                        return <GeneralContext.Consumer>{ (ver)=> <h2>{msg} | {ver}</h2>}</GeneralContext.Consumer>
                    }}</FamilyContext.Consumer>
               </div>
}
export default CousinComp;