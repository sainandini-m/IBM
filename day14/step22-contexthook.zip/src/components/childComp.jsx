import { useContext } from "react";
import FamilyContext from "../context/family.context";

function ChildComp(){
    const value = useContext( FamilyContext );
    return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                    <h2>Child Component</h2>
                    <hr />
                    <FamilyContext.Consumer>{ (value)=> <h2>{value}</h2>}</FamilyContext.Consumer>
            </div>
}

export default ChildComp;