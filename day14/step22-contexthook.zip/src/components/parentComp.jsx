import {  useContext } from "react";
import GeneralContext from "../context/gen.context";
import ChildComp from "./childComp";

function ParentComp (){
    const value = useContext(GeneralContext)
    return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                <h2>Parent Component</h2>
                <GeneralContext.Consumer>{ (value)=> <h2>{value}</h2>}</GeneralContext.Consumer>
                <hr/>
                <ChildComp/>
            </div>
}

export default ParentComp;