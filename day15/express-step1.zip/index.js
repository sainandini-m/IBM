const express = require("express");
let config = require("./config.json");
const fs = require("fs");
let app = express();

let data = [];
// middleware 
app.use(express.json());
app.use(express.static(__dirname+"/public"));

app.get("/", function( req, res ){
    res.sendFile(__dirname+"/public/index.html");
});
app.get("/data", function( req, res ){
    data = JSON.parse(fs.readFileSync(__dirname+"/data/data.json"));
    res.status(200).send(data);
});
app.post("/data", function( req, res ){
   data.push(req.body); 
   fs.writeFile(__dirname+"/data/data.json", JSON.stringify(data), function(err, data){
    res.send(data);
   });
});

app.listen(config.port, config.host);
console.log("Server is now live on localhost : ", config.port);