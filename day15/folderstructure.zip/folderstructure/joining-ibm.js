let greeting = require("ibm");
console.log(greeting.message);