const redux = require("redux");
const createStore = redux.createStore;

// action
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";

// action creator
function addHero(){
    return {
        type : ADD_HERO,
        info : "First Redux Action"
    }
}
function removeHero(){
    return {
        type : REMOVE_HERO,
        info : "Second Redux Action"
    }
}

// default state object
const initialState = {
    numberOfHeroes : 0
}

// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return{
            numberOfHeroes : state.numberOfHeroes + 1
        }
        case REMOVE_HERO : return{
            numberOfHeroes : state.numberOfHeroes - 1
        }
        default : return state
    }
}

// creating a store
const store = createStore( reducer );

// console.log( store.getState() );

const unsubscribe = store.subscribe( ()=>{
    console.log( store.getState() );
});


store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( removeHero() );
console.log("remove hero called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( removeHero() );
console.log("remove hero called");
store.dispatch( addHero() );
console.log("add hero called");

unsubscribe();
console.log("unsubscribed");

store.dispatch( addHero() );
console.log("called addHero after unsubscribe ");