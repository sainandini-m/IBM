const redux = require("redux");
const thunkMiddleware = require("redux-thunk").default;
const axios = require("axios");
//----------------------------
const createStore = redux.createStore;
const applyMiddleware = redux.applyMiddleware;

// actions
const AXIOS_USER_REQUEST = "AXIOS_USER_REQUEST";
const AXIOS_USER_SUCCESS = "AXIOS_USER_SUCCESS";
const AXIOS_USER_ERROR = "AXIOS_USER_ERROR";

// action creators
const fetchUsers = ()=>{
    return {
        type : AXIOS_USER_REQUEST
    }
}
const fetchUserSuccess = (users)=>{
    return {
        type : AXIOS_USER_SUCCESS,
        payload : users
    }
}
const fetchUserError = (error)=>{
    return {
        type : AXIOS_USER_ERROR,
        payload : error
    }
}
// default state values
const initialState = {
    loading : false,
    users : [],
    error : ''
}

// reducers
const reducer = (state = initialState, action) => {
    switch(action.type){
        case AXIOS_USER_REQUEST : return {
            ...state,
            loading : true
        }
        case AXIOS_USER_SUCCESS : return {
            ...state,
            loading : false,
            users : action.payload,
            error : ''
        }
        case AXIOS_USER_ERROR : return {
            ...state,
            loading : false,
            users : [],
            error : action.payload
        }
        default : return state
    }
}

// thunk action;
const thunkFetchUsers = ()=>{
    return function(dispatch){
        dispatch( fetchUsers() );
    }
}
// thunk ajax action;
const thunkAjaxFetchUsers = ()=>{
    return function(dispatch){
        axios.get("https://jsonplaceholder.typicode.com/users").then(
            (response) => { 
                dispatch(fetchUserSuccess(response.data)) 
            }
        ).catch((error) => { 
            dispatch(fetchUserError(error)) 
        } )
    }
}

// create a store
const store = createStore( reducer, applyMiddleware(thunkMiddleware) );

store.subscribe(()=>{
    console.log(store.getState())
});

store.dispatch( thunkFetchUsers() );

setTimeout(()=>{
    store.dispatch( thunkAjaxFetchUsers() );
}, 2000);



