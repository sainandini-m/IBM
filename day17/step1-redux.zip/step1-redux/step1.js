const redux = require("redux");
const createStore = redux.createStore;

// action
const ADD_HERO = "ADD_HERO";

// action creator
function addHero(){
    return {
        type : ADD_HERO,
        info : "First Redux Action"
    }
}

// default state object
const initialState = {
    numberOfHeroes : 5
}

// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return{
            numberOfHeroes : state.numberOfHeroes + 1
        }
        default : return state
    }
}

// creating a store
const store = createStore( reducer );

// console.log( store.getState() );

store.subscribe( ()=>{
    console.log( store.getState() );
});


store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
