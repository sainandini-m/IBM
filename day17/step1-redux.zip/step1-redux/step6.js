const redux = require("redux");
// const reduxLogger = require("redux-logger");
//--------------------------------------------
const createStore = redux.createStore;
const combineReducers = redux.combineReducers;
const applyMiddleware = redux.applyMiddleware;
// const logger = reduxLogger.createLogger();

function ibmLogger({ getState }) {
    return next => action => {
      console.log('will dispatch', action);
      const returnValue = next(action) ;
      console.log('state after dispatch', getState())
      return returnValue
    }
  }

// action
const ADD_HERO = "ADD_HERO";
const ADD_MOVIE = "ADD_MOVIE";

// action creator
function addHero(){
    return {
        type : ADD_HERO,
        info : "First Redux Action"
    }
}
function addMovie(){
    return {
        type : ADD_MOVIE,
        info : "Second Redux Action"
    }
}

// default state object
const initialHeroState = {
    heroes : 0
}
// default state object
const initialMovieState = {
    movies : 0
}

// reducers
const heroReducer = (state = initialHeroState, action)=>{
    switch(action.type){
        case ADD_HERO : return{
            heroes : state.heroes + 1
        }
        default : return state
    }
}
const movieReducer = (state = initialMovieState, action)=>{
    switch(action.type){
        case ADD_MOVIE : return{
            ...state,
            movies : state.movies + 1
        }
        default : return state
    }
}

const rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

// creating a store
const store = createStore( rootReducer, applyMiddleware(ibmLogger) );

const unsubscribe = store.subscribe(()=>{});

store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addMovie() );
store.dispatch( addHero() );
store.dispatch( addMovie() );
store.dispatch( addHero() );

unsubscribe();