const redux = require("redux");
const createStore = redux.createStore;

// action
const ADD_HERO = "ADD_HERO";
const ADD_MOVIE = "ADD_MOVIE";

// action creator
function addHero(){
    return {
        type : ADD_HERO,
        info : "First Redux Action"
    }
}
function addMovie(){
    return {
        type : ADD_MOVIE,
        info : "Second Redux Action"
    }
}

// default state object
const initialState = {
    numberOfHeroes : 0,
    numberOfMovies : 0
}

// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return{
            ...state,
            numberOfHeroes : state.numberOfHeroes + 1
        }
        case ADD_MOVIE : return{
            ...state,
            numberOfMovies : state.numberOfMovies + 1
        }
        default : return state
    }
}

// creating a store
const store = createStore( reducer );

// console.log( store.getState() );

const unsubscribe = store.subscribe( ()=>{
    console.log( store.getState() );
});


store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addMovie() );
console.log("add movie called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addMovie() );
console.log("add movie called");
store.dispatch( addHero() );
console.log("add hero called");

unsubscribe();
console.log("unsubscribed");

store.dispatch( addHero() );
console.log("called addHero after unsubscribe ");