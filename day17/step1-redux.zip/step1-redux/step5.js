const redux = require("redux");
const createStore = redux.createStore;
const combineReducers = redux.combineReducers;

// action
const ADD_HERO = "ADD_HERO";
const ADD_MOVIE = "ADD_MOVIE";

// action creator
function addHero(){
    return {
        type : ADD_HERO,
        info : "First Redux Action"
    }
}
function addMovie(){
    return {
        type : ADD_MOVIE,
        info : "Second Redux Action"
    }
}

// default state object
const initialHeroState = {
    heroes : 10
}
// default state object
const initialMovieState = {
    movies : 10
}

// reducers
const heroReducer = (state = initialHeroState, action)=>{
    switch(action.type){
        case ADD_HERO : return{
            heroes : state.heroes + 1
        }
        default : return state
    }
}
const movieReducer = (state = initialMovieState, action)=>{
    switch(action.type){
        case ADD_MOVIE : return{
            ...state,
            movies : state.movies + 1
        }
        default : return state
    }
}

const rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

// creating a store
const store = createStore( rootReducer );

// console.log( store.getState() );

const unsubscribe = store.subscribe( ()=>{
    console.log( store.getState() );
});


store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addMovie() );
console.log("add movie called");
store.dispatch( addHero() );
console.log("add hero called");
store.dispatch( addMovie() );
console.log("add movie called");
store.dispatch( addHero() );
console.log("add hero called");

unsubscribe();
console.log("unsubscribed");

store.dispatch( addHero() );
console.log("called addHero after unsubscribe ");