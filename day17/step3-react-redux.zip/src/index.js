import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import HeroComp from './components/HeroComp';
import HeroHookComp from './components/HeroHookComp';
import store from './redux/store';

class MainApp extends Component{
  render(){
    return <div>
            <h1>React Redux Application</h1>
            <Provider store={ store }>
              <HeroComp/>
            </Provider>
            <hr/>
            <Provider store={ store }>
              <HeroHookComp/>
            </Provider>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));