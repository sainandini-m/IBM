import { useSelector, useDispatch } from 'react-redux';
import { addHero } from '../redux';
function HeroHookComp(){
    const numOfHeroes = useSelector( state => state.numOfHeroes );
    const dispatch = useDispatch();
    return <div>
                <h1>Avengers Enrollment Program Using Hooks </h1>
                <h2>Number of avengers recruited :  { numOfHeroes } </h2>
                <button onClick={ ()=>{ dispatch( addHero() ) } }>Add Avenger</button>
            </div>
}
export default HeroHookComp;