// import addHero from "./hero/actions/hero.action";
// export default addHero;

import addHero from "./hero/actions/hero.action";
export { addHero }