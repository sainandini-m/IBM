// Action Type

export const ADD_HERO = "ADD_HERO";