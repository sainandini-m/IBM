import { useEffect, useState } from "react";

function EffectsComp(){
let [power, updatePower] = useState(0);
let [version, updateVersion] = useState(0);

useEffect(()=>{
    console.log("Component did Mount")
},[]); // componentDidMount

useEffect(()=>{
    console.log("Component did Updated");
},[power]); // componentDidUpdate

useEffect(()=>{
    return () => console.log("Component did Unmount");
},[]); // componentWillUnmount



// useEffect(()=>{
//     console.log("Component did Updated");
//     return () => console.log("Component did Unmount");
// },[power]); 



return <div>
        <h1> Use Effect Component </h1>
        <h2>Power is : { power }</h2>
        <h2>Version is : { version }</h2>
        <button onClick={()=>{ updatePower(power + 1) }}>Click to increase power</button>
        <button onClick={()=>{ updateVersion(version + 1) }}>Click to increase version</button>
    </div>
}

export default EffectsComp;