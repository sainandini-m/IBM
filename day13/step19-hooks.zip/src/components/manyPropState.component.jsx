import { useState } from "react";

function ManyPropStateComp(){
    let [ heroInfo, updateHeroInfo ] = useState({'firstName':'Tony', 'lastName':'Stark'});
    return <div>
            <h1>Use State with many properties</h1>
            <h2>Full Name : {heroInfo.firstName} {heroInfo.lastName}</h2>
            <button onClick={()=> updateHeroInfo({ ...heroInfo, 'firstName' : 'Bruce' }) }>Change First Name to Bruce</button>
            <button onClick={()=> updateHeroInfo({ ...heroInfo, 'lastName' : 'Wayne' }) }>Change Last Name to Wayne</button>
           </div>
}
export default ManyPropStateComp;