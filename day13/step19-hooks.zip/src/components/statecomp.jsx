import {useState} from 'react';
function CompUseState(){
    // console.log( useState() );
    let [power, updatePower] = useState(0); // stateProperty, manageStateProperty
    let [uname, updateName] = useState('Vijay'); // stateProperty, manageStateProperty
    return <div>
                <h1>Using UseState Hook Demo</h1>
                <h2>Power value is : { power } </h2>
                <h2>User Name is : { uname } </h2>
                <button onClick={ ()=>{ updatePower(power+1) }}>Increase Power</button>
                <button onClick={ ()=>{ updatePower(power-1) }}>Decrease Power</button>
                <button onClick={ ()=>{ updateName('Bengaloorean') }}>Change Name</button>
           </div>
}
export default CompUseState;