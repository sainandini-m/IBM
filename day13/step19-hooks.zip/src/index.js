import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import EffectsComp from './components/effects.component';
import ManyPropStateComp from './components/manyPropState.component';
import CompUseState from './components/statecomp';

function MainApp(){
  let [show, changeShow] = useState(true);
  return <div>
          <CompUseState/>
          <hr/>
          <ManyPropStateComp/>
          <hr/>
          <button onClick={()=> changeShow(show = !show)}>Show / Hide</button>
          <hr/>
          { show ? <EffectsComp/> : <h1>Comp is Hidden</h1>}
          
        </div>
};

ReactDOM.render(<MainApp/>,document.getElementById('root'));