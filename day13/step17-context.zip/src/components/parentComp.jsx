import { Component } from "react";
import GeneralContext from "../context/gen.context";
import ChildComp from "./childComp";

class ParentComp extends Component{
    render(){
        return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                    <h2>Parent Component</h2>
                    <GeneralContext.Consumer>{ (value)=> <h2>{value}</h2>}</GeneralContext.Consumer>
                    <hr/>
                    <ChildComp/>
                </div>
    }
}

export default ParentComp;