import { Component } from "react";
import { FamilyProvider } from "../context/family.context";
import GeneralContext from "../context/gen.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parentComp";

class GrandComp extends Component{
    state = {
        message : "Grand Parent Message",
        version : 1001
    }
    changeMessage = ()=>{
        this.setState({
            message : "Updated Message"
        })
    }
    changeVersion = ()=>{
        this.setState({
            version : Math.round(Math.random() * 10000)
        })
    }
    render(){
        return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                <h2>Grand Component</h2>
                <button onClick={ this.changeMessage }>Change Message</button>
                <button onClick={ this.changeVersion }>Change Version</button>
                <hr/>
                <FamilyProvider value={ this.state.message }>
                    <GeneralContext.Provider value={ this.state.version }>
                        <ParentComp/>
                        <hr />
                        <CousinComp/>
                    </GeneralContext.Provider>
                </FamilyProvider>
               </div>
               
    }
}

export default GrandComp;