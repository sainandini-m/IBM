import { Component } from "react";
import { FamilyConsumer } from "../context/family.context";
import GeneralContext from "../context/gen.context";

class CousinComp extends Component{
    render(){
        return <div style={ { border : "2px solid red", margin : "10px", padding : "10px"} }>
                    <h2>Cousin Component</h2>
                    <hr />
                    {/* <FamilyConsumer>{ (value)=> <h2>{value}</h2>}</FamilyConsumer>
                    <GeneralContext.Consumer>{ (value)=> <h2>{value}</h2>}</GeneralContext.Consumer> */}
                    <FamilyConsumer>{ (msg)=> {
                        return <GeneralContext.Consumer>{ (ver)=> <h2>{msg} | {ver}</h2>}</GeneralContext.Consumer>
                    }}</FamilyConsumer>
                    
               </div>
    }
}

export default CousinComp;