import React from 'react';

const GeneralContext = React.createContext();

export default GeneralContext;