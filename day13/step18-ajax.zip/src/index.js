import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import ListComp from './components/list.component';

class MainApp extends Component{
  state = {
    users : []
  }
  clickHandler = ()=>{
    axios.get("https://jsonplaceholder.typicode.com/users")
    .then((res)=>{
      this.setState({
        users : res.data
      })
    }).catch((error)=> console.log("Error : ", error))
  }
  render(){
    return <div>
            <h1>Heroes List Application</h1>
            <button onClick={ this.clickHandler }>Get Data</button>
            <ul>
              { this.state.users.map(val => <ListComp key={val.id} user={val}/>) }
            </ul>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));