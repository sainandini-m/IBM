import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import fetch from 'fetch';

class MainApp extends Component{
  state = {
    users : []
  }
  clickHandler = ()=>{
    fetch.fetchUrl("https://jsonplaceholder.typicode.com/users", (err,meta, data)=>{
      if(err){
        console.log("Error : ", err);
      }else{
        // console.log(err, meta, JSON.parse(data));
        this.setState({
          users : JSON.parse(data)
        })
      }
    })
  }
  render(){
    return <div>
            <h1>Heroes List Application</h1>
            <button onClick={ this.clickHandler }>Get Data</button>
            <ul>
              { this.state.users.map(val => <li key={ val.id }>{val.name}</li>) }
            </ul>
          </div>
  }
}

ReactDOM.render(<MainApp/>,document.getElementById('root'));