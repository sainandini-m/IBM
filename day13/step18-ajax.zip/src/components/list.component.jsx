import { Component } from "react";

class ListComp extends Component{

    render(){
        let {name, username, email, address, phone, website, company} = this.props.user;
        return <li>
        Name : { name } 
          <ol>
            <li> User Name : { username } </li>
            <li> eMail : { email } </li>
            <li> City : { address.city } </li>
            <li> Phone : { phone } </li>
            <li> Website : { website } </li>
            <li> Company Name : { company.name } </li>
          </ol>
        </li>
    }
}

export default ListComp;